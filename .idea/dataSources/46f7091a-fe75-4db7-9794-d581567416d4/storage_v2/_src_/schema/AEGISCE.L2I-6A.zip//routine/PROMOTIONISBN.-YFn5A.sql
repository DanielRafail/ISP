create FUNCTION promotionISBN(uIsbn IN VARCHAR2) RETURN VARCHAR2
AS
    vIsbn VARCHAR2(20);
    vRetail NUMBER;
    vGift VARCHAR2(20);
BEGIN 
    SELECT b.isbn, b.retail, p.gift INTO vIsbn, vRetail, vGift FROM books b
    INNER JOIN promotion p ON b.retail BETWEEN p.minretail AND p.maxretail
    WHERE b.isbn = uIsbn;
    return vGift;
END;
/

