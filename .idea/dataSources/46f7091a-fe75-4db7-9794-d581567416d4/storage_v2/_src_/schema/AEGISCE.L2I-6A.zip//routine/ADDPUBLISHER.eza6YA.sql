create PROCEDURE 
 addPublisher(pPublisherId IN NUMBER, pPublisherName IN VARCHAR2, pPublisherContact IN VARCHAR2, pPublisherPhone IN VARCHAR2)
 AS
    TYPE tIdArray IS VARRAY(50) OF NUMBER(2,0);
    vId tIdArray;
    TYPE tNameArray IS VARRAY(50) OF VARCHAR2(23);
    vName tNameArray;
    TYPE tContactArray IS VARRAY(50) OF VARCHAR2(15);
    vContact tContactArray;
    TYPE tPhoneArray IS VARRAY(50) OF VARCHAR2(12);
    vPhone tPhoneArray;
    i NUMBER(4,0) := 1;
    ePublisherExists EXCEPTION;
 BEGIN 
    SELECT pubid, name, contact, phone BULK COLLECT INTO vId, vName, vContact, vPhone FROM publisher;
    FOR i IN 1 .. 10 LOOP
        vId.EXTEND;
        vName.EXTEND;
        vContact.EXTEND;
        vPhone.EXTEND;
        IF pPublisherId = vId(i) THEN
            RAISE ePublisherExists;
        ELSIF pPublisherName = vName(i) THEN
            RAISE ePublisherExists;
        ELSIF pPublisherContact = vContact(i) THEN
            RAISE ePublisherExists;
        ELSIF pPublisherPhone = vPhone(i) THEN
            RAISE ePublisherExists;
        END IF;
    END LOOP;
    INSERT INTO publisher (pubid, name, contact, phone)
    VALUES (pPublisherId, pPublisherName, pPublisherContact, pPublisherPhone); 
 EXCEPTION
    WHEN ePublisherExists THEN
        dbms_output.put_line('Publisher already exists.');
 END;
/

