create PROCEDURE changeCategory(pCategory IN VARCHAR2, pNameChangeTo IN VARCHAR2)
AS
    TYPE tCategory IS VARRAY(50) OF VARCHAR2(20);
    vCategory tCategory;
    i NUMBER(4,0) := 1;
    vCounter NUMBER(4,0) := 0;
    eCategoryNotFound EXCEPTION;    
BEGIN
    SELECT category BULK COLLECT INTO vCategory FROM books;
    FOR i IN 1 .. 30 LOOP
        vCategory.EXTEND;
        IF(vCategory(i) = pCategory) THEN
            vCounter := vCounter + 1;
        END IF;
    END LOOP;
    IF vCounter = 0 THEN
        RAISE eCategoryNotFound;
    END IF;
    UPDATE Books
    SET category = pNameChangeTo
    WHERE category = pCategory;  
EXCEPTION       
    WHEN eCategoryNotFound THEN
        dbms_output.put_line('Category not found.');
END;
/

