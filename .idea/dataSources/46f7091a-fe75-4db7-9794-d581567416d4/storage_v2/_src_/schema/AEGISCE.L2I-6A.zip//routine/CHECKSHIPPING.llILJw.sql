create FUNCTION checkShipping(uIsbn IN VARCHAR2) RETURN VARCHAR2
AS
    vShipping VARCHAR(20);
BEGIN 
    IF promotionISBN(uIsbn) = 'FREE SHIPPING' THEN
        vShipping := 'FREE SHIPPING';
    ELSE
        vShipping := 'NO FREE SHIPPING';
    END IF;
    return vShipping;  
END;
/

