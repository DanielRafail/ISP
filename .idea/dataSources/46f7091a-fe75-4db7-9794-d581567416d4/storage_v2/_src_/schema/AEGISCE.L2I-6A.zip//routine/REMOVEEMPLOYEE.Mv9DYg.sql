create procedure removeEmployee(pEmployeeID in varchar2, pManagerID in varchar2) as
  vEmployeeID VARCHAR2(100);
  vManagerID VARCHAR2(100);
  begin
    SELECT EmployeeID, ManagerID INTO vEmployeeID, vManagerID FROM representatives
    WHERE EmployeeID = pEmployeeID;


          UPDATE representatives
          SET active = '0'
          WHERE vEmployeeID = pEmployeeID;

  end removeEmployee;
/

