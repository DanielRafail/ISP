create PROCEDURE cancelUnshipped(custID IN NUMBER)
AS
    TYPE custIdArray IS VARRAY(30) OF NUMBER;
    tCustID custIdArray;  
    TYPE shipDateArray IS VARRAY(30) OF DATE;
    tShipDate shipDateArray;
    TYPE orderArray IS VARRAY(30) OF NUMBER;
    tOrder orderArray;
BEGIN
    SELECT o.customer#, o.shipdate, o.order# BULK COLLECT INTO tCustID, tShipDate, tOrder FROM orders o
    INNER JOIN orderitems oi ON o.order# = oi.order#
    WHERE o.customer# = custID AND o.shipdate IS NULL;
    DELETE FROM orderitems
    WHERE order# = (SELECT order# FROM orders WHERE customer# = custID AND shipdate IS NULL);
    DELETE FROM orders
    WHERE customer# = custID AND shipdate IS NULL;
END;
/

