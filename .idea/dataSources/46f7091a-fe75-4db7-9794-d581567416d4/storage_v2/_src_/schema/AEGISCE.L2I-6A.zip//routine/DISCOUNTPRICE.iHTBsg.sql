create FUNCTION discountPrice(uIsbn IN VARCHAR2) RETURN NUMBER
AS
    vIsbn VARCHAR2(10);
    vRetail NUMBER;
    vDiscount NUMBER;
BEGIN
    SELECT isbn, retail, discount INTO vIsbn, vRetail, vDiscount FROM books 
    WHERE isbn = uIsbn;
    IF vDiscount IS NULL THEN
        vDiscount := 0;
    END IF;
    vRetail := vRetail + (vRetail - vDiscount) * 0.15;
    return vRetail;
END;
/

