create procedure addEmployee(EmployeeID in varchar2, name in varchar2, position in varchar2, phone in varchar2, email in varchar2, managerID in varchar2, passwordHash in raw, salt in varchar2, passwordExpired in varchar2) as
begin
    Insert into Representatives values(EmployeeID, name, position, phone, email, managerID, passwordHash, salt, passwordExpired);
end;
/

