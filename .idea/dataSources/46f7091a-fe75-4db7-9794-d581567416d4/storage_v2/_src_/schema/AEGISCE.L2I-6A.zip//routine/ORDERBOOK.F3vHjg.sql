create PROCEDURE orderBook(client# IN NUMBER, uIsbn IN VARCHAR2)
AS  
    vIsbn VARCHAR2(20);
    vRetail NUMBER;
BEGIN
    INSERT INTO orders (order#, customer#, orderdate, shipdate, shipstreet, shipcity, shipstate, shipzip, shipcost)
    VALUES (client#, 1020, '06-APR-09', null, '4321 THIS STREET', 'SEATTLE', 'WA', 84726, 3);
    SELECT isbn, retail INTO vIsbn, vRetail FROM books
    WHERE isbn = uIsbn;
    INSERT INTO orderitems (order#, item#, isbn, quantity, paideach) 
    VALUES (client#, 1, uIsbn, 1, vRetail);
END;
/

