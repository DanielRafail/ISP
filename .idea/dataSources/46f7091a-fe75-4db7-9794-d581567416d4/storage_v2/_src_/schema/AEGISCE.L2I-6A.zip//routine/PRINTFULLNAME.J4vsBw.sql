create FUNCTION
 printFullName(pISBN IN NUMBER) 
 RETURN VARCHAR2 AS
    TYPE tNameArray IS VARRAY(50) OF VARCHAR2(20);
    vName tNameArray;
    i NUMBER(4,0) := 1;
    NO_AUTHORS EXCEPTION;
    TOO_MANY_AUTHORS EXCEPTION;
 BEGIN
    SELECT (a.lname || ', ' || a.fname) BULK COLLECT INTO vName FROM author a
    JOIN bookauthor ba ON a.authorid = ba.authorid
    JOIN books b ON ba.isbn = b.isbn
    WHERE b.isbn = pISBN;
    vName.EXTEND;
    IF vName(1) IS NULL THEN
        RAISE NO_AUTHORS;
        RETURN NULL;
    ELSIF vName(2) IS NOT NULL THEN
        RAISE too_many_authors;
        RETURN NULL;
    ELSE
        RETURN vName(1);
    END IF;
 EXCEPTION
    WHEN NO_AUTHORS THEN    
        dbms_output.put_line('Author does not exist.');       
    WHEN too_many_authors THEN  
        dbms_output.put_line('More than 1 author name found.');
 END;
/

