create PROCEDURE applyDiscount(ccategory IN VARCHAR2, discountAmount IN NUMBER)
AS
    TYPE retailarray IS VARRAY(30) OF NUMBER;
    tRetail retailarray;
    TYPE discountlarray IS VARRAY(30) OF NUMBER;
    tDiscount discountlarray;
    TYPE categoryarray IS VARRAY(30) OF VARCHAR2(20);
    tCategory categoryarray;   
BEGIN
    SELECT b.retail, b.discount, b.category BULK COLLECT INTO tRetail, tDiscount, tCategory FROM books b
    WHERE category = ccategory;
    UPDATE books SET discount = discountAmount
    WHERE category = ccategory;
END;
/

